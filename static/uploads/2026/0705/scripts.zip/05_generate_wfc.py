"""
Script 5: Generate Pattern with Wave Function Collapse (WFC)
=============================================================
A simplified implementation of the Wave Function Collapse algorithm.
WFC enforces local adjacency constraints, producing patterns where
certain color transitions are preferred or forbidden.

Usage:
    uv run python scripts/05_generate_wfc.py [--rows 30] [--cols 40] [--colors 5]

Output:
    - output/wfc_pattern.png       : visualization
    - output/wfc_matrix.txt        : the tile matrix
"""

import argparse
import random

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")


def build_adjacency_rules(n_colors: int, seed: int = 42) -> np.ndarray:
    """Build adjacency rules that create clustering.

    Returns a (n_colors, n_colors) boolean matrix where rules[a, b] = True
    means tile a can be placed adjacent to tile b.

    We design rules so that:
    - Same colors can always be adjacent (promotes clustering)
    - Adjacent colors in the palette are more likely to be compatible
    - Distant colors in the palette are less likely (creates contrast boundaries)
    """
    rng = random.Random(seed)

    rules = np.zeros((n_colors, n_colors), dtype=bool)

    for a in range(n_colors):
        for b in range(n_colors):
            if a == b:
                rules[a, b] = True  # same color always OK
            elif abs(a - b) == 1:
                rules[a, b] = True  # adjacent in palette: allowed
            elif abs(a - b) == 2:
                # Somewhat unlikely but possible
                rules[a, b] = rng.random() < 0.5
            else:
                # Very unlikely for distant colors
                rules[a, b] = rng.random() < 0.15

    # Ensure symmetry
    rules = rules | rules.T
    return rules


def print_rules(rules: np.ndarray) -> None:
    """Pretty-print adjacency rules."""
    n = len(rules)
    print("  Adjacency rules (rows = left, cols = right):")
    header = "     " + " ".join(f"  {i}  " for i in range(n))
    print(header)
    for a in range(n):
        row = "  " + " ".join(" [X] " if rules[a, b] else " [ ] " for b in range(n))
        print(f"  {a} {row}")


def wave_function_collapse(
    rows: int, cols: int, rules: np.ndarray, seed: int = 42
) -> np.ndarray:
    """Simplified WFC: collapse tiles one by one, respecting adjacency rules.

    This is a minimal implementation:
    1. Start with all tiles in a superposition of all possible states.
    2. Pick the tile with lowest entropy (fewest remaining possibilities).
    3. Collapse it to a random valid state.
    4. Propagate constraints to neighbors.
    5. Repeat until all tiles are collapsed.
    """
    n_colors = len(rules)
    rng = random.Random(seed)

    # State: for each cell, a bitmask of possible colors
    # Bit i is set if color i is still possible
    all_possible = (1 << n_colors) - 1
    state = np.full((rows, cols), all_possible, dtype=np.uint64)
    collapsed = np.full((rows, cols), -1, dtype=int)

    # Helper: count bits set in a mask
    def bit_count(mask: int) -> int:
        return mask.bit_count()

    # Precompute: for each color, which colors can be its neighbor
    # possible_neighbors[c] = bitmask of colors allowed adjacent to c
    possible_neighbors = np.zeros(n_colors, dtype=np.uint64)
    for c in range(n_colors):
        mask = 0
        for b in range(n_colors):
            if rules[c, b]:
                mask |= 1 << b
        possible_neighbors[c] = mask

    def propagate():
        """Propagate constraints: iterate until stable."""
        changed = True
        while changed:
            changed = False
            for i in range(rows):
                for j in range(cols):
                    if collapsed[i, j] >= 0:
                        continue
                    current = state[i, j]
                    if current == 0:
                        continue  # contradiction (shouldn't happen)

                    # Check neighbors and compute allowed colors
                    allowed = current
                    for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                        ni, nj = i + di, j + dj
                        if 0 <= ni < rows and 0 <= nj < cols:
                            if collapsed[ni, nj] >= 0:
                                c = collapsed[ni, nj]
                                # This tile must allow a color that can be adjacent to c
                                neighbor_mask = 0
                                for color in range(n_colors):
                                    if (current >> color) & 1 and rules[c, color]:
                                        neighbor_mask |= 1 << color
                                allowed &= neighbor_mask

                    if allowed != current:
                        state[i, j] = allowed
                        changed = True

    # Main loop
    remaining = rows * cols
    while remaining > 0:
        # Find tile with minimum entropy (fewest remaining possibilities)
        min_entropy = n_colors + 1
        candidates = []

        for i in range(rows):
            for j in range(cols):
                if collapsed[i, j] >= 0:
                    continue
                n_possible = bit_count(state[i, j])
                if n_possible == 0:
                    # Contradiction: restart from this region
                    # Simple fallback: force collapse to most likely color
                    state[i, j] = 1 << (rng.randint(0, n_colors - 1))
                    n_possible = 1
                if n_possible < min_entropy:
                    min_entropy = n_possible
                    candidates = [(i, j)]
                elif n_possible == min_entropy:
                    candidates.append((i, j))

        if not candidates:
            break

        # Choose randomly among minimum-entropy candidates
        i, j = rng.choice(candidates)

        # Collapse: pick a random possible color
        possible_colors = [c for c in range(n_colors) if (state[i, j] >> c) & 1]
        chosen = rng.choice(possible_colors)
        collapsed[i, j] = chosen
        state[i, j] = 1 << chosen
        remaining -= 1

        # Propagate constraints
        propagate()

    return collapsed


def make_palette(n_colors: int) -> np.ndarray:
    palettes = {
        3: [(34, 139, 34), (107, 142, 35), (154, 205, 50)],
        4: [(25, 65, 20), (50, 100, 45), (90, 145, 80), (140, 185, 130)],
        5: [(25, 41, 16), (41, 57, 31), (59, 82, 47), (76, 103, 64), (118, 154, 122)],
        6: [
            (25, 41, 16),
            (41, 57, 31),
            (59, 82, 47),
            (76, 103, 64),
            (100, 130, 100),
            (140, 175, 140),
        ],
    }
    if n_colors in palettes:
        return np.array(palettes[n_colors], dtype=np.uint8)
    cmap = plt.get_cmap("Greens")
    return np.array(
        [np.array(cmap(i / (n_colors - 1))[:3]) * 255 for i in range(n_colors)],
        dtype=np.uint8,
    )


def main():
    parser = argparse.ArgumentParser(
        description="Generate tile pattern using Wave Function Collapse"
    )
    parser.add_argument("--rows", type=int, default=30, help="Number of rows")
    parser.add_argument("--cols", type=int, default=40, help="Number of columns")
    parser.add_argument("--colors", type=int, default=5, help="Number of colors")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    print(
        f"Generating {args.rows}x{args.cols} WFC pattern with {args.colors} colors..."
    )

    # Build adjacency rules (hand-crafted for clustering)
    rules = build_adjacency_rules(args.colors, seed=args.seed)
    print("Adjacency rules:")
    print_rules(rules)

    # Run WFC
    matrix = wave_function_collapse(args.rows, args.cols, rules, seed=args.seed)
    palette = make_palette(args.colors)

    # Save matrix
    np.savetxt("output/wfc_matrix.txt", matrix, fmt="%d")

    # Render
    image = palette[matrix]
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax0 = axes[0]
    # Visualize the rules as a small graph
    rule_img = np.zeros((args.colors * 20, args.colors * 20, 3), dtype=np.uint8)
    for a in range(args.colors):
        for b in range(args.colors):
            color = palette[b] if rules[a, b] else (30, 30, 30)
            rule_img[a * 20 : (a + 1) * 20, b * 20 : (b + 1) * 20] = color
    ax0.imshow(rule_img)
    ax0.set_title("Adjacency Rules (row=left, col=right)", fontsize=12)
    ax0.set_xlabel("Right neighbor color")
    ax0.set_ylabel("Left neighbor color")
    # Add tick labels
    ax0.set_xticks(range(10, args.colors * 20, 20))
    ax0.set_yticks(range(10, args.colors * 20, 20))
    ax0.set_xticklabels(range(args.colors))
    ax0.set_yticklabels(range(args.colors))

    ax1 = axes[1]
    ax1.imshow(image)
    ax1.set_title(
        f"WFC Pattern ({args.rows}x{args.cols}, {args.colors} colors)", fontsize=12
    )
    ax1.axis("off")

    plt.suptitle(
        "Wave Function Collapse Pattern (constrained adjacency)",
        fontsize=14,
        y=1.02,
    )
    plt.tight_layout()
    plt.savefig("output/wfc_pattern.png", dpi=150, bbox_inches="tight")
    print("Saved output/wfc_pattern.png")
    print("Saved output/wfc_matrix.txt")

    # Summary
    print(f"\nColor distribution:")
    for i in range(args.colors):
        count = (matrix == i).sum()
        print(f"  Color {i}: {count:4d} tiles ({100 * count / matrix.size:.1f}%)")

    # Count transitions
    h, w = matrix.shape
    transitions = 0
    for i in range(h):
        for j in range(1, w):
            if matrix[i, j] != matrix[i, j - 1]:
                transitions += 1
    for j in range(w):
        for i in range(1, h):
            if matrix[i, j] != matrix[i - 1, j]:
                transitions += 1

    max_possible = 2 * h * (w - 1) + 2 * w * (h - 1)
    print(f"\nEdge transitions: {transitions} / {max_possible}")
    print(f"  (Lower = more clustering)")


if __name__ == "__main__":
    main()
