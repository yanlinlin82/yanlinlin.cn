"""
Script 6: Comprehensive Metrics Comparison
============================================
Generate patterns using all methods (pure random, Perlin noise, WFC),
evaluate each with all randomness metrics, and produce a comparison table + figure.

This script ties together everything from scripts 2-5.

Usage:
    uv run python scripts/06_metrics_comparison.py [--rows 30] [--cols 40] [--colors 5]

Output:
    - output/comparison_table.txt   : ASCII table of all metrics
    - output/comparison_figure.png  : side-by-side visual comparison
    - output/running_*.png          : running example for each method
"""

import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import chi2 as chi2_dist

matplotlib.use("Agg")


# ── Shared utilities ─────────────────────────────────────────────────


def render_with_mortar(
    matrix: np.ndarray,
    palette: np.ndarray,
    tile_size: int = 10,
    mortar_width: int = 2,
    mortar_color=(20, 25, 18),
) -> np.ndarray:
    """Render a tile matrix as an image with mortar-style borders between tiles."""
    rows, cols = matrix.shape
    img_h = rows * tile_size + (rows + 1) * mortar_width
    img_w = cols * tile_size + (cols + 1) * mortar_width
    img = np.full((img_h, img_w, 3), list(mortar_color), dtype=np.uint8)
    for i in range(rows):
        for j in range(cols):
            y = i * (tile_size + mortar_width) + mortar_width
            x = j * (tile_size + mortar_width) + mortar_width
            img[y : y + tile_size, x : x + tile_size] = palette[matrix[i, j]]
    return img


def make_palette(n_colors: int) -> np.ndarray:
    palettes = {
        3: [(34, 139, 34), (107, 142, 35), (154, 205, 50)],
        4: [(25, 65, 20), (50, 100, 45), (90, 145, 80), (140, 185, 130)],
        5: [(25, 41, 16), (41, 57, 31), (59, 82, 47), (76, 103, 64), (118, 154, 122)],
        6: [
            (25, 41, 16),
            (41, 57, 31),
            (59, 82, 47),
            (76, 103, 64),
            (100, 130, 100),
            (140, 175, 140),
        ],
    }
    if n_colors in palettes:
        return np.array(palettes[n_colors], dtype=np.uint8)
    cmap = plt.get_cmap("Greens")
    return np.array(
        [np.array(cmap(i / (n_colors - 1))[:3]) * 255 for i in range(n_colors)],
        dtype=np.uint8,
    )


# ──────────────────────────────────────────────────────────────────────
# Generators (simplified versions)
# ──────────────────────────────────────────────────────────────────────


def gen_random(rows: int, cols: int, n_colors: int, seed: int = 42) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.integers(0, n_colors, size=(rows, cols))


def gen_perlin(rows: int, cols: int, n_colors: int, seed: int = 42) -> np.ndarray:
    """Perlin noise generation (full implementation from script 4)."""
    rng = np.random.default_rng(seed)

    def perlin_octave(w, h, scale, s):
        rng2 = np.random.default_rng(s)
        n_grid = int(np.ceil(max(w, h) / scale)) + 2
        angles = rng2.uniform(0, 2 * np.pi, (n_grid + 1, n_grid + 1))
        gx = np.cos(angles)
        gy = np.sin(angles)
        noise = np.zeros((h, w))
        for y in range(h):
            for x in range(w):
                sx, sy = x / scale, y / scale
                x0, y0 = int(np.floor(sx)), int(np.floor(sy))
                x1, y1 = x0 + 1, y0 + 1
                lx, ly = sx - x0, sy - y0
                u = lx * lx * (3 - 2 * lx)
                v = ly * ly * (3 - 2 * ly)

                def dot(gx, gy, dx, dy):
                    return gx * dx + gy * dy

                n00 = dot(gx[y0, x0], gy[y0, x0], lx, ly)
                n10 = dot(gx[y0, x1], gy[y0, x1], lx - 1, ly)
                n01 = dot(gx[y1, x0], gy[y1, x0], lx, ly - 1)
                n11 = dot(gx[y1, x1], gy[y1, x1], lx - 1, ly - 1)
                nx0 = n00 + u * (n10 - n00)
                nx1 = n01 + u * (n11 - n01)
                noise[y, x] = nx0 + v * (nx1 - nx0)
        return noise

    result = np.zeros((rows, cols))
    amp = 1.0
    max_val = 0.0
    for o in range(4):
        scale = 2.0**o * 3.0
        noise = perlin_octave(cols, rows, scale, rng.integers(0, 10000))
        result += amp * noise
        max_val += amp
        amp *= 0.5
    result /= max_val

    # Normalize and quantize
    r_min, r_max = result.min(), result.max()
    normalized = (result - r_min) / (r_max - r_min)
    bins = np.linspace(0, 1, n_colors + 1)
    labels = np.digitize(normalized, bins[:-1]) - 1
    return np.clip(labels, 0, n_colors - 1)


def gen_wfc(rows: int, cols: int, n_colors: int, seed: int = 42) -> np.ndarray:
    """Wave Function Collapse (simplified, from script 5)."""
    import random as _random

    _rng = _random.Random(seed)

    rules = np.zeros((n_colors, n_colors), dtype=bool)
    for a in range(n_colors):
        for b in range(n_colors):
            if a == b:
                rules[a, b] = True
            elif abs(a - b) == 1:
                rules[a, b] = True
            elif abs(a - b) == 2:
                rules[a, b] = _rng.random() < 0.5
            else:
                rules[a, b] = _rng.random() < 0.15
    rules = rules | rules.T

    all_mask = (1 << n_colors) - 1
    state = np.full((rows, cols), all_mask, dtype=np.uint64)
    collapsed = np.full((rows, cols), -1, dtype=int)

    possible_neighbors = np.zeros(n_colors, dtype=np.uint64)
    for c in range(n_colors):
        mask = 0
        for b in range(n_colors):
            if rules[c, b]:
                mask |= 1 << b
        possible_neighbors[c] = mask

    def propagate():
        changed = True
        while changed:
            changed = False
            for i in range(rows):
                for j in range(cols):
                    if collapsed[i, j] >= 0:
                        continue
                    cur = state[i, j]
                    if cur == 0:
                        continue
                    allowed = cur
                    for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                        ni, nj = i + di, j + dj
                        if 0 <= ni < rows and 0 <= nj < cols and collapsed[ni, nj] >= 0:
                            c = collapsed[ni, nj]
                            mask = 0
                            for color in range(n_colors):
                                if (cur >> color) & 1 and rules[c, color]:
                                    mask |= 1 << color
                            allowed &= mask
                    if allowed != cur:
                        state[i, j] = allowed
                        changed = True

    remaining = rows * cols
    while remaining > 0:
        min_entropy = n_colors + 1
        candidates = []
        for i in range(rows):
            for j in range(cols):
                if collapsed[i, j] >= 0:
                    continue
                n_possible = state[i, j].bit_count()
                if n_possible == 0:
                    state[i, j] = 1 << _rng.randint(0, n_colors - 1)
                    n_possible = 1
                if n_possible < min_entropy:
                    min_entropy = n_possible
                    candidates = [(i, j)]
                elif n_possible == min_entropy:
                    candidates.append((i, j))

        if not candidates:
            break

        i, j = _rng.choice(candidates)
        possible = [c for c in range(n_colors) if (state[i, j] >> c) & 1]
        chosen = _rng.choice(possible)
        collapsed[i, j] = chosen
        state[i, j] = 1 << chosen
        remaining -= 1
        propagate()

    return collapsed


# ──────────────────────────────────────────────────────────────────────
# Metrics (same as script 2)
# ──────────────────────────────────────────────────────────────────────


def entropy(matrix):
    counts = np.bincount(matrix.ravel())
    probs = counts[counts > 0] / matrix.size
    h = -np.sum(probs * np.log2(probs))
    h_max = np.log2(len(counts))
    return h / h_max if h_max > 0 else 0


def morans_i(matrix):
    n = matrix.size
    z = matrix.ravel().astype(float)
    z_bar = z.mean()
    z_dev = z - z_bar
    s2 = np.sum(z_dev**2) / n
    h, w = matrix.shape
    total_w = 0.0
    wcov = 0.0
    for i in range(h):
        for j in range(w):
            idx = i * w + j
            for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                ni, nj = i + di, j + dj
                if 0 <= ni < h and 0 <= nj < w:
                    nidx = ni * w + nj
                    wcov += z_dev[idx] * z_dev[nidx]
                    total_w += 1.0
    if total_w == 0 or s2 == 0:
        return 0.0
    return (n / total_w) * (wcov / (n * s2))


def runs_ratio(matrix):
    h, w = matrix.shape
    transitions = 0
    for i in range(h):
        for j in range(1, w):
            if matrix[i, j] != matrix[i, j - 1]:
                transitions += 1
    for j in range(w):
        for i in range(1, h):
            if matrix[i, j] != matrix[i - 1, j]:
                transitions += 1
    counts = np.bincount(matrix.ravel())
    probs = counts / matrix.size
    p_same = np.sum(probs**2)
    expected = (h * (w - 1) + w * (h - 1)) * (1 - p_same)
    return transitions / expected if expected > 0 else 1.0


def mutual_info(matrix):
    h, w = matrix.shape
    pairs = []
    for i in range(h):
        for j in range(w - 1):
            pairs.append((matrix[i, j], matrix[i, j + 1]))
    pairs = np.array(pairs)
    n = len(pairs)
    if n == 0:
        return 0.0
    n_colors = int(matrix.max()) + 1
    joint = np.zeros((n_colors, n_colors))
    for a, b in pairs:
        joint[a, b] += 1
    joint /= n
    p_x = joint.sum(axis=1)
    p_y = joint.sum(axis=0)
    mi = 0.0
    for i2 in range(n_colors):
        for j2 in range(n_colors):
            if joint[i2, j2] > 0:
                mi += joint[i2, j2] * np.log2(joint[i2, j2] / (p_x[i2] * p_y[j2]))
    return mi


def chi_square_p(matrix):
    counts = np.bincount(matrix.ravel())
    expected = matrix.size / len(counts)
    chi2 = np.sum((counts - expected) ** 2 / expected)
    df = len(counts) - 1
    return 1 - chi2_dist.cdf(chi2, df)


# ──────────────────────────────────────────────────────────────────────
# Main comparison
# ──────────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Comprehensive metrics comparison across generation methods"
    )
    parser.add_argument("--rows", type=int, default=30, help="Number of rows")
    parser.add_argument("--cols", type=int, default=40, help="Number of columns")
    parser.add_argument("--colors", type=int, default=5, help="Number of colors")
    parser.add_argument(
        "--tile-size", type=int, default=10, help="Rendered tile size in pixels"
    )
    parser.add_argument(
        "--mortar", type=int, default=2, help="Mortar line width in pixels"
    )
    parser.add_argument(
        "--original-matrix",
        default="output/matrix.txt",
        help="Path to extracted original matrix (for matching color distribution)",
    )
    args = parser.parse_args()

    rows, cols, n_colors = args.rows, args.cols, args.colors
    palette = make_palette(n_colors)

    # Try to load original matrix for color distribution
    orig_probs = None
    try:
        orig_mat = np.loadtxt(args.original_matrix, dtype=int)
        orig_counts = np.bincount(orig_mat.ravel(), minlength=n_colors)
        orig_probs = orig_counts / orig_counts.sum()
        print(
            f"Loaded original from {args.original_matrix} ({orig_mat.shape[0]}x{orig_mat.shape[1]})"
        )
        print(
            f"  Color distribution: {dict(zip(range(n_colors), np.round(orig_probs, 3)))}"
        )
    except Exception:
        print(
            "  (Original matrix not found; all random generators use uniform distribution)"
        )

    print(
        f"\nGenerating and evaluating {rows}x{cols} patterns with {n_colors} colors...\n"
    )

    # Generator definitions: returns (matrix, label_suffix)
    def gen_random_matched(r, c, nc):
        rng = np.random.default_rng(42)
        p = orig_probs if orig_probs is not None else np.ones(nc) / nc
        return rng.choice(nc, size=(r, c), p=p).astype(int)

    generators = {"Pure Random (uniform)": gen_random}
    if orig_probs is not None:
        generators["Pure Random (matched)"] = gen_random_matched
    generators["Perlin Noise"] = gen_perlin
    generators["WFC"] = gen_wfc

    results = {}
    matrices = {}

    for name, gen_fn in generators.items():
        print(f"  Generating: {name}")
        matrix = gen_fn(rows, cols, n_colors)
        matrices[name] = matrix

        results[name] = {
            "Entropy (norm)": f"{entropy(matrix):.3f}",
            "Moran's I": f"{morans_i(matrix):.4f}",
            "Runs Ratio": f"{runs_ratio(matrix):.3f}",
            "Mutual Info": f"{mutual_info(matrix):.4f}",
            "Chi-sq p-val": f"{chi_square_p(matrix):.4f}",
        }

    # Build and print comparison table
    print("\n" + "=" * 85)
    print("  COMPARISON TABLE: Randomness Metrics Across Generation Methods")
    print("=" * 85)

    metric_names = list(next(iter(results.values())).keys())
    header = f"{'Method':<16}" + "".join(f"  {m:>15}" for m in metric_names)
    print(header)
    print("-" * len(header))

    for name, metrics in results.items():
        row = f"{name:<16}" + "".join(f"  {v:>15}" for v in metrics.values())
        print(row)

    print("=" * 85)
    print()

    # Interpretation guide
    print("How to read this table:")
    print("  Entropy (norm)  : 1.0 = perfectly uniform color distribution")
    print("  Moran's I       : ~0 = random, >0 = clustered, <0 = alternating")
    print(
        "  Runs Ratio      : 1.0 = expected transitions, <1 = clumped, >1 = alternating"
    )
    print("  Mutual Info     : ~0 = independent neighbors, >0 = structured")
    print("  Chi-sq p-val    : >0.05 = uniform color frequencies\n")

    # Save comparison table
    with open("output/comparison_table.txt", "w") as f:
        f.write("Comparison Table: Randomness Metrics\n")
        f.write("=" * 85 + "\n")
        f.write(header + "\n")
        f.write("-" * len(header) + "\n")
        for name, metrics in results.items():
            row = f"{name:<16}" + "".join(f"  {v:>15}" for v in metrics.values())
            f.write(row + "\n")
    print("Saved output/comparison_table.txt")

    # ──────────────────────────────────────────────────────────────────
    # Figure: side-by-side comparison with original photo
    # ──────────────────────────────────────────────────────────────────
    try:
        from PIL import Image as PILImage

        original_arr = np.array(PILImage.open("pattern.png").convert("RGB"))
        has_original = True
    except Exception:
        has_original = False

    n_methods = len(generators) + (1 if has_original else 0)
    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    axes_flat = axes.ravel()

    plot_idx = 0

    if has_original:
        ax = axes_flat[plot_idx]
        ax.imshow(original_arr)
        ax.set_title("Original Photo", fontsize=13, fontweight="bold")
        ax.axis("off")
        plot_idx += 1

    for name in generators:
        ax = axes_flat[plot_idx]
        matrix = matrices[name]
        ax.imshow(render_with_mortar(matrix, palette, args.tile_size, args.mortar))
        ax.set_title(name, fontsize=13, fontweight="bold")
        ax.axis("off")

        # Annotate key metrics in the corner
        mi_val = mutual_info(matrix)
        moran_val = morans_i(matrix)
        text = f"MI={mi_val:.3f}  I={moran_val:.3f}"
        ax.text(
            0.03,
            0.97,
            text,
            transform=ax.transAxes,
            fontsize=9,
            verticalalignment="top",
            color="white",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="black", alpha=0.6),
        )
        plot_idx += 1

    # Hide unused subplots
    for idx in range(plot_idx, len(axes_flat)):
        axes_flat[idx].axis("off")

    plt.suptitle(
        "Visual Comparison: Random vs Structured Generation",
        fontsize=16,
        fontweight="bold",
        y=1.01,
    )
    plt.tight_layout()
    plt.savefig("output/comparison_figure.png", dpi=150, bbox_inches="tight")
    print("Saved output/comparison_figure.png")

    # ──────────────────────────────────────────────────────────────────
    # Bar chart comparison
    # ──────────────────────────────────────────────────────────────────
    fig2, axes2 = plt.subplots(1, 3, figsize=(15, 4.5))

    # Collect data
    names = list(generators.keys())
    ent_vals = [entropy(matrices[n]) for n in names]
    moran_vals = [morans_i(matrices[n]) for n in names]
    run_vals = [runs_ratio(matrices[n]) for n in names]

    # Color scheme for bars, cycling if more than available colors
    bar_colors_pool = ["#4a8a5c", "#2d6633", "#1a4a2a", "#7bba8a", "#3d6b4f"]
    colors_bar = [bar_colors_pool[i % len(bar_colors_pool)] for i in range(len(names))]

    for ax, vals, title, ylabel in zip(
        axes2,
        [ent_vals, moran_vals, run_vals],
        ["Normalized Entropy", "Moran's I", "Runs Ratio"],
        ["H / H_max", "I value", "Observed / Expected"],
    ):
        bars = ax.bar(
            names, vals, color=colors_bar, width=0.5, edgecolor="black", linewidth=0.5
        )
        ax.set_title(title, fontsize=12, fontweight="bold")
        ax.set_ylabel(ylabel, fontsize=10)
        ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)
        if title == "Moran's I":
            ax.axhline(y=0, color="red", linestyle=":", alpha=0.7, label="random (I=0)")
        elif title == "Runs Ratio":
            ax.axhline(
                y=1, color="red", linestyle=":", alpha=0.7, label="random (ratio=1)"
            )
        elif title == "Normalized Entropy":
            ax.axhline(y=1, color="red", linestyle=":", alpha=0.7, label="max entropy")
        # Add value labels on bars
        for bar, val in zip(bars, vals):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + abs(bar.get_height()) * 0.02,
                f"{val:.3f}",
                ha="center",
                va="bottom" if val >= 0 else "top",
                fontsize=9,
            )
        ax.set_ylim(
            min(min(vals) * 1.2, -0.1),
            max(max(vals) * 1.2, 1.2),
        )
        ax.legend(fontsize=8)

    plt.suptitle(
        "Metrics Comparison Across Generation Methods", fontsize=14, fontweight="bold"
    )
    plt.tight_layout()
    plt.savefig("output/comparison_barchart.png", dpi=150, bbox_inches="tight")
    print("Saved output/comparison_barchart.png")


if __name__ == "__main__":
    main()
