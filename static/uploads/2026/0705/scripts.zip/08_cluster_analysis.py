"""
Script 8: Cluster Analysis
============================
Connected-component (cluster) analysis of tile patterns.

Moran's I and other spatial metrics are powerful, but their numbers can be
hard to interpret intuitively.  Cluster analysis provides a more
human-readable answer: "how big do same-color patches get?"

This script compares cluster size distributions across:
  - Original photo extraction
  - Pure random (uniform distribution)
  - Pure random (matched to original's color distribution)
  - Perlin Noise (strong clustering)
  - WFC (adjacency-constrained)

Usage:
    uv run python scripts/08_cluster_analysis.py

Output:
    - output/cluster_stats.txt       : ASCII table of cluster statistics
    - output/cluster_distribution.png : violin/histogram of cluster sizes
    - output/cluster_map.png          : visual overlay of clusters on patterns
"""

import importlib.util
import warnings

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage

matplotlib.use("Agg")
warnings.filterwarnings("ignore", category=UserWarning)


def load_matrices() -> dict:
    """Load or generate all comparison matrices at the original size (47x78)."""
    original = np.loadtxt("output/matrix.txt", dtype=int)

    rng = np.random.default_rng(42)
    orig_counts = np.bincount(original.ravel(), minlength=5)
    orig_probs = orig_counts / orig_counts.sum()
    rand_match = rng.choice(5, size=original.shape, p=orig_probs).astype(int)
    rand_uni = rng.integers(0, 5, size=original.shape)

    perlin = np.loadtxt("output/perlin_matrix.txt", dtype=int)
    wfc = np.loadtxt("output/wfc_matrix.txt", dtype=int)

    return {
        "Original": original,
        "Random (matched)": rand_match,
        "Random (uniform)": rand_uni,
        "Perlin Noise": perlin,
        "WFC": wfc,
    }


def cluster_analysis(matrix: np.ndarray) -> dict:
    """Compute cluster statistics for all colors combined.

    A "cluster" is a connected component of same-color tiles
    (8-connectivity: including diagonals).
    """
    n_colors = int(matrix.max()) + 1
    all_sizes = []
    per_color = {}

    for c in range(n_colors):
        binary = matrix == c
        labeled, n = ndimage.label(binary, structure=np.ones((3, 3)))
        sizes = np.bincount(labeled.ravel())[1:]  # index 0 is background
        all_sizes.extend(sizes)
        per_color[c] = {"count": n, "sizes": sizes}

    all_sizes = np.array(all_sizes)
    total_tiles = matrix.size

    return {
        "n_clusters": len(all_sizes),
        "n_clusters_per_1000": len(all_sizes) / total_tiles * 1000,
        "mean_size": all_sizes.mean(),
        "median_size": np.median(all_sizes),
        "max_size": all_sizes.max(),
        "std_size": all_sizes.std(),
        "pct_singleton": (all_sizes == 1).mean() * 100,
        "pct_in_largest": all_sizes.max() / total_tiles * 100,
        "size_distribution": all_sizes,
        "per_color": per_color,
    }


def main():
    print("Loading matrices (all at 47x78)...")
    matrices = load_matrices()
    results = {}

    for name, mat in matrices.items():
        print(f"  Analyzing: {name} ({mat.shape[0]}x{mat.shape[1]})")
        results[name] = cluster_analysis(mat)

    # ── ASCII table ────────────────────────────────────────────────
    print("\n" + "=" * 95)
    print("  CLUSTER ANALYSIS: Connected-Component Statistics")
    print("=" * 95)
    header = (
        f"{'Method':<20} {'Clusters':>9} {'/1000t':>7}"
        f" {'Mean sz':>8} {'Median':>7} {'Max sz':>8}"
        f" {'Std sz':>8} {'%Single':>8} {'%InLarge':>9}"
    )
    print(header)
    print("-" * len(header))

    for name in matrices:
        r = results[name]
        print(
            f"{name:<20} {r['n_clusters']:>9} {r['n_clusters_per_1000']:>7.1f}"
            f" {r['mean_size']:>8.1f} {r['median_size']:>7.1f} {r['max_size']:>8}"
            f" {r['std_size']:>8.1f} {r['pct_singleton']:>7.1f}% {r['pct_in_largest']:>8.2f}%"
        )

    print("=" * 95)

    # Also print Moran's I / MI / Runs for reference
    spec = importlib.util.spec_from_file_location(
        "evalmod", "scripts/02_eval_randomness.py"
    )
    eval_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(eval_mod)

    print("\n" + "=" * 50)
    print("  Reference: Spatial Metrics")
    print("=" * 50)
    print(f"{'Method':<20} {'Morans I':>10} {'MI':>8} {'Runs':>8}")
    print("-" * 50)
    for name, mat in matrices.items():
        mi = eval_mod.mutual_information_neighbor(mat)["mutual_information"]
        moran = eval_mod.morans_i(mat)["morans_i"]
        runs = eval_mod.runs_test_2d(mat)["ratio"]
        print(f"{name:<20} {moran:>10.3f} {mi:>8.3f} {runs:>8.2f}")

    # Save table
    with open("output/cluster_stats.txt", "w") as f:
        f.write("Cluster Analysis: Connected-Component Statistics\n")
        f.write("=" * 95 + "\n")
        f.write(header + "\n")
        f.write("-" * len(header) + "\n")
        for name in matrices:
            r = results[name]
            f.write(
                f"{name:<20} {r['n_clusters']:>9} {r['n_clusters_per_1000']:>7.1f}"
                f" {r['mean_size']:>8.1f} {r['median_size']:>7.1f} {r['max_size']:>8}"
                f" {r['std_size']:>8.1f} {r['pct_singleton']:>7.1f}% {r['pct_in_largest']:>8.2f}%\n"
            )
    print("\nSaved output/cluster_stats.txt")

    # ── Cluster size distribution histogram ────────────────────────
    print("Generating cluster distribution plot...")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))

    names_plot = ["Original", "Random (matched)", "Perlin Noise"]
    colors_plot = ["#c0392b", "#2d6633", "#1a4a2a"]

    for ax, name, color in zip(axes, names_plot, colors_plot):
        sizes = results[name]["size_distribution"]
        # Log-log histogram
        bins = np.logspace(np.log10(0.5), np.log10(max(sizes.max(), 10)), 30)
        ax.hist(
            sizes, bins=bins, color=color, alpha=0.7, edgecolor="white", linewidth=0.3
        )
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_title(name, fontsize=12, fontweight="bold")
        ax.set_xlabel("Cluster size (tiles)")
        ax.set_ylabel("Frequency")
        # Mark mean
        mean_sz = results[name]["mean_size"]
        ax.axvline(
            mean_sz, color="red", linestyle="--", alpha=0.7, label=f"mean={mean_sz:.1f}"
        )
        ax.legend(fontsize=8)

    plt.suptitle(
        "Cluster Size Distributions (log-log scale)\n"
        "(Original has fatter tail than random, but nowhere near Perlin)",
        fontsize=13,
        fontweight="bold",
    )
    plt.tight_layout()
    plt.savefig("output/cluster_distribution.png", dpi=150, bbox_inches="tight")
    print("Saved output/cluster_distribution.png")

    # ── Visual cluster overlay ─────────────────────────────────────
    print("Generating cluster map visualization...")
    from matplotlib.colors import ListedColormap

    # Show a zoomed 30x40 region for visual clarity
    fig2, axes2 = plt.subplots(1, 3, figsize=(16, 5))
    palette = np.array(
        [
            [25, 41, 16],
            [76, 103, 65],
            [41, 56, 31],
            [59, 83, 47],
            [118, 154, 121],
        ],
        dtype=np.uint8,
    )

    for ax, (name, mat) in zip(
        axes2,
        [
            ("Original (full)", matrices["Original"]),
            ("Original (zoom 0:30, 0:40)", matrices["Original"][:30, :40]),
            (
                "Random (matched, zoom 0:30, 0:40)",
                matrices["Random (matched)"][:30, :40],
            ),
        ],
    ):
        # Render with mortar
        rows, cols = mat.shape
        ts, mw = 10, 2
        h_img = rows * ts + (rows + 1) * mw
        w_img = cols * ts + (cols + 1) * mw
        img = np.full((h_img, w_img, 3), [20, 25, 18], dtype=np.uint8)
        for i in range(rows):
            for j in range(cols):
                y = i * (ts + mw) + mw
                x = j * (ts + mw) + mw
                img[y : y + ts, x : x + ts] = palette[mat[i, j]]
        ax.imshow(img)
        ax.set_title(name, fontsize=11, fontweight="bold")
        ax.axis("off")

    plt.suptitle(
        "Visual Detail: Original vs Random (mortar borders)",
        fontsize=13,
        fontweight="bold",
    )
    plt.tight_layout()
    plt.savefig("output/cluster_map.png", dpi=150, bbox_inches="tight")
    print("Saved output/cluster_map.png")

    # ── Interpret ──────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  INTERPRETATION")
    print("=" * 70)

    orig = results["Original"]
    rand = results["Random (matched)"]
    perlin_r = results["Perlin Noise"]

    print(f"\n  Mean cluster size:")
    print(f"    Original:        {orig['mean_size']:.1f} tiles")
    print(
        f"    Random (matched): {rand['mean_size']:.1f} tiles  ({orig['mean_size'] / rand['mean_size']:.1f}x smaller)"
    )
    print(
        f"    Perlin Noise:    {perlin_r['mean_size']:.1f} tiles  ({perlin_r['mean_size'] / orig['mean_size']:.1f}x larger)"
    )

    print(f"\n  Largest cluster:")
    print(
        f"    Original:        {orig['max_size']} tiles ({orig['pct_in_largest']:.1f}% of all tiles)"
    )
    print(
        f"    Random (matched): {rand['max_size']} tiles ({rand['pct_in_largest']:.1f}% of all tiles)"
    )
    print(
        f"    Perlin Noise:    {perlin_r['max_size']} tiles ({perlin_r['pct_in_largest']:.1f}% of all tiles)"
    )

    print(f"\n  Singleton clusters (isolated single tile):")
    print(f"    Original:        {orig['pct_singleton']:.1f}%")
    print(f"    Random (matched): {rand['pct_singleton']:.1f}%")
    print(f"    Perlin Noise:    {perlin_r['pct_singleton']:.1f}%")

    print(f"\n  Bottom line:")
    print(f"  - The original has noticeably more clustering than pure random")
    print(f"    (2x mean cluster size, 4x largest cluster).")
    print(f"  - But it is FAR from Perlin Noise's extreme blobbiness")
    print(
        f"    (Perlin's largest cluster is {perlin_r['max_size'] / orig['max_size']:.0f}x larger)."
    )
    print(f"  - Visually, the original sits in a middle ground: detectable")
    print(f"    structure, but subtle enough to blend in at a glance.")
    print("=" * 70)


if __name__ == "__main__":
    main()
