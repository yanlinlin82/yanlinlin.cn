"""
Script 4: Generate Pattern with Perlin Noise
=============================================
Generate a tile pattern using Perlin Noise, which creates natural-looking
clusters -- like "forests" and "lakes" of similar colors.

Rendered with mortar-style borders to match the original photo's style.

Usage:
    uv run python scripts/04_generate_perlin.py [--rows 30] [--cols 40] [--colors 5]

Output:
    - output/perlin_pattern.png    : visualization (with mortar borders)
    - output/perlin_matrix.txt     : the tile matrix
"""

import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")


def render_with_mortar(
    matrix: np.ndarray,
    palette: np.ndarray,
    tile_size: int = 10,
    mortar_width: int = 2,
    mortar_color=(20, 25, 18),
) -> np.ndarray:
    rows, cols = matrix.shape
    img_h = rows * tile_size + (rows + 1) * mortar_width
    img_w = cols * tile_size + (cols + 1) * mortar_width
    img = np.full((img_h, img_w, 3), list(mortar_color), dtype=np.uint8)
    for i in range(rows):
        for j in range(cols):
            y = i * (tile_size + mortar_width) + mortar_width
            x = j * (tile_size + mortar_width) + mortar_width
            img[y : y + tile_size, x : x + tile_size] = palette[matrix[i, j]]
    return img


def perlin_noise_2d(
    width: int, height: int, scale: float = 5.0, seed: int = None
) -> np.ndarray:
    """Generate 2D Perlin noise using layered gradients (fractal Brownian motion)."""
    rng = np.random.default_rng(seed)
    grad_size = max(width, height)
    n_grid = int(np.ceil(grad_size / scale)) + 2
    angles = rng.uniform(0, 2 * np.pi, (n_grid + 1, n_grid + 1))
    gx = np.cos(angles)
    gy = np.sin(angles)
    noise = np.zeros((height, width))
    for y in range(height):
        for x in range(width):
            sx, sy = x / scale, y / scale
            x0, y0 = int(np.floor(sx)), int(np.floor(sy))
            x1, y1 = x0 + 1, y0 + 1
            lx, ly = sx - x0, sy - y0
            u = lx * lx * (3 - 2 * lx)
            v = ly * ly * (3 - 2 * ly)

            def dot(gx_val, gy_val, dx, dy):
                return gx_val * dx + gy_val * dy

            n00 = dot(gx[y0, x0], gy[y0, x0], lx, ly)
            n10 = dot(gx[y0, x1], gy[y0, x1], lx - 1, ly)
            n01 = dot(gx[y1, x0], gy[y1, x0], lx, ly - 1)
            n11 = dot(gx[y1, x1], gy[y1, x1], lx - 1, ly - 1)
            nx0 = n00 + u * (n10 - n00)
            nx1 = n01 + u * (n11 - n01)
            noise[y, x] = nx0 + v * (nx1 - nx0)
    return noise


def fractal_brownian_motion(
    width: int,
    height: int,
    octaves: int = 4,
    persistence: float = 0.5,
    seed: int = None,
) -> np.ndarray:
    """Fractal Brownian Motion: sum multiple Perlin noise layers at different scales."""
    result = np.zeros((height, width))
    amplitude = 1.0
    max_val = 0.0
    rng = np.random.default_rng(seed)
    for o in range(octaves):
        scale = 2.0**o * 3.0
        noise = perlin_noise_2d(width, height, scale=scale, seed=rng.integers(0, 10000))
        result += amplitude * noise
        max_val += amplitude
        amplitude *= persistence
    return result / max_val


def noise_to_tiles(noise: np.ndarray, n_colors: int) -> np.ndarray:
    """Quantize continuous noise into discrete tile labels."""
    n_min, n_max = noise.min(), noise.max()
    if n_max - n_min < 1e-10:
        normalized = np.zeros_like(noise)
    else:
        normalized = (noise - n_min) / (n_max - n_min)
    bins = np.linspace(0, 1, n_colors + 1)
    labels = np.digitize(normalized, bins[:-1]) - 1
    return np.clip(labels, 0, n_colors - 1)


def make_palette(n_colors: int) -> np.ndarray:
    palettes = {
        3: [(34, 139, 34), (107, 142, 35), (154, 205, 50)],
        4: [(25, 65, 20), (50, 100, 45), (90, 145, 80), (140, 185, 130)],
        5: [(25, 41, 16), (41, 57, 31), (59, 82, 47), (76, 103, 64), (118, 154, 122)],
        6: [
            (25, 41, 16),
            (41, 57, 31),
            (59, 82, 47),
            (76, 103, 64),
            (100, 130, 100),
            (140, 175, 140),
        ],
    }
    if n_colors in palettes:
        return np.array(palettes[n_colors], dtype=np.uint8)
    cmap = plt.get_cmap("Greens")
    return np.array(
        [np.array(cmap(i / (n_colors - 1))[:3]) * 255 for i in range(n_colors)],
        dtype=np.uint8,
    )


def main():
    parser = argparse.ArgumentParser(
        description="Generate tile pattern using Perlin Noise"
    )
    parser.add_argument("--rows", type=int, default=30, help="Number of rows")
    parser.add_argument("--cols", type=int, default=40, help="Number of columns")
    parser.add_argument("--colors", type=int, default=5, help="Number of colors")
    parser.add_argument(
        "--octaves", type=int, default=4, help="FBM octaves (more = finer detail)"
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument(
        "--tile-size", type=int, default=10, help="Rendered tile size in pixels"
    )
    parser.add_argument(
        "--mortar", type=int, default=2, help="Mortar line width in pixels"
    )
    args = parser.parse_args()

    print(f"Generating {args.rows}x{args.cols} Perlin noise pattern...")
    print(f"  Octaves: {args.octaves}, Colors: {args.colors}")

    noise = fractal_brownian_motion(
        args.cols, args.rows, octaves=args.octaves, seed=args.seed
    )
    matrix = noise_to_tiles(noise, args.colors)
    palette = make_palette(args.colors)

    # Save matrix
    np.savetxt("output/perlin_matrix.txt", matrix, fmt="%d")

    # Render with mortar borders
    image = render_with_mortar(matrix, palette, args.tile_size, args.mortar)
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax0 = axes[0]
    im0 = ax0.imshow(noise, cmap="viridis")
    ax0.set_title("Perlin Noise (continuous)", fontsize=12)
    ax0.axis("off")
    plt.colorbar(im0, ax=ax0, fraction=0.046)

    ax1 = axes[1]
    ax1.imshow(image)
    ax1.set_title(
        f"Quantized to {args.colors} colors ({args.rows}x{args.cols})", fontsize=12
    )
    ax1.axis("off")

    plt.suptitle(
        "Perlin Noise Pattern (colors form natural clusters)",
        fontsize=14,
        y=1.02,
    )
    plt.tight_layout()
    plt.savefig("output/perlin_pattern.png", dpi=150, bbox_inches="tight")
    print("Saved output/perlin_pattern.png")
    print("Saved output/perlin_matrix.txt")

    print(f"\nColor distribution:")
    for i in range(args.colors):
        count = (matrix == i).sum()
        print(f"  Color {i}: {count:4d} tiles ({100 * count / matrix.size:.1f}%)")


if __name__ == "__main__":
    main()
