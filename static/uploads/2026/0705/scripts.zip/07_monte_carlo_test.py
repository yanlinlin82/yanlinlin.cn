"""
Script 7: Monte Carlo Randomness Test
=======================================
Test whether the original pattern's metrics are consistent with pure randomness.

Core idea:
  1. Generate thousands of purely random patterns (same size, same color count,
     optionally matching the original's color distribution).
  2. Compute the same metrics for each random pattern.
  3. See where the original photo's metrics fall in the distribution.
  4. If the original is an extreme outlier (e.g. beyond 95% of randoms),
     we reject the hypothesis that it's purely random.

Additionally tests the "color count hypothesis":
  - With fewer colors, does random naturally look more "clustered"?
  - We repeat the test with different numbers of colors to see how
    the metric distributions shift.

Usage:
    uv run python scripts/07_monte_carlo_test.py [--n-samples 999] [--rows 47] [--cols 78]

Output:
    - output/monte_carlo_histograms.png   : metric distributions + original
    - output/monte_carlo_color_count.png  : effect of color count on metrics
    - output/monte_carlo_visual.png       : original vs 11 random samples (with borders)
    - Printed summary with empirical p-values
"""

import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")

SEED = 42
rng = np.random.default_rng(SEED)


# ── Load original pattern ──────────────────────────────────────────────


def load_matrix(path: str) -> np.ndarray:
    return np.loadtxt(path, dtype=int)


# ── Metrics ────────────────────────────────────────────────────────────


def morans_i(matrix: np.ndarray) -> float:
    n = matrix.size
    z = matrix.ravel().astype(float)
    z_bar = z.mean()
    z_dev = z - z_bar
    s2 = np.sum(z_dev**2) / n
    h, w = matrix.shape
    total_w = 0.0
    wcov = 0.0
    for i in range(h):
        for j in range(w):
            idx = i * w + j
            for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                ni, nj = i + di, j + dj
                if 0 <= ni < h and 0 <= nj < w:
                    nidx = ni * w + nj
                    wcov += z_dev[idx] * z_dev[nidx]
                    total_w += 1.0
    if total_w == 0 or s2 == 0:
        return 0.0
    return (n / total_w) * (wcov / (n * s2))


def mutual_info(matrix: np.ndarray) -> float:
    h, w = matrix.shape
    pairs = []
    for i in range(h):
        for j in range(w - 1):
            pairs.append((matrix[i, j], matrix[i, j + 1]))
    pairs = np.array(pairs)
    n = len(pairs)
    if n == 0:
        return 0.0
    n_colors = int(matrix.max()) + 1
    joint = np.zeros((n_colors, n_colors))
    for a, b in pairs:
        joint[a, b] += 1
    joint /= n
    p_x = joint.sum(axis=1)
    p_y = joint.sum(axis=0)
    mi = 0.0
    for i2 in range(n_colors):
        for j2 in range(n_colors):
            if joint[i2, j2] > 0:
                mi += joint[i2, j2] * np.log2(joint[i2, j2] / (p_x[i2] * p_y[j2]))
    return mi


def runs_ratio(matrix: np.ndarray) -> float:
    h, w = matrix.shape
    transitions = 0
    for i in range(h):
        for j in range(1, w):
            if matrix[i, j] != matrix[i, j - 1]:
                transitions += 1
    for j in range(w):
        for i in range(1, h):
            if matrix[i, j] != matrix[i - 1, j]:
                transitions += 1
    counts = np.bincount(matrix.ravel())
    probs = counts / matrix.size
    p_same = np.sum(probs**2)
    expected = (h * (w - 1) + w * (h - 1)) * (1 - p_same)
    return transitions / expected if expected > 0 else 1.0


def entropy(matrix: np.ndarray) -> float:
    counts = np.bincount(matrix.ravel())
    probs = counts[counts > 0] / matrix.size
    h = -np.sum(probs * np.log2(probs))
    h_max = np.log2(len(counts))
    return h / h_max if h_max > 0 else 0


# ── Generate random patterns ──────────────────────────────────────────


def gen_random_with_probs(rows: int, cols: int, probs: np.ndarray) -> np.ndarray:
    return rng.choice(len(probs), size=(rows, cols), p=probs).astype(int)


def render_with_mortar(
    matrix: np.ndarray,
    palette: np.ndarray,
    tile_size: int = 10,
    mortar_width: int = 2,
    mortar_color=(20, 25, 18),
) -> np.ndarray:
    """Render a tile matrix as an image with mortar-style borders between tiles."""
    rows, cols = matrix.shape
    img_h = rows * tile_size + (rows + 1) * mortar_width
    img_w = cols * tile_size + (cols + 1) * mortar_width
    img = np.full((img_h, img_w, 3), list(mortar_color), dtype=np.uint8)
    for i in range(rows):
        for j in range(cols):
            y = i * (tile_size + mortar_width) + mortar_width
            x = j * (tile_size + mortar_width) + mortar_width
            img[y : y + tile_size, x : x + tile_size] = palette[matrix[i, j]]
    return img


def make_palette(n_colors: int) -> np.ndarray:
    palettes = {
        5: np.array(
            [
                [25, 41, 16],
                [76, 103, 65],
                [41, 56, 31],
                [59, 83, 47],
                [118, 154, 121],
            ],
            dtype=np.uint8,
        ),
    }
    if n_colors in palettes:
        return palettes[n_colors]
    cmap = plt.get_cmap("Greens")
    return np.array(
        [np.array(cmap(i / (n_colors - 1))[:3]) * 255 for i in range(n_colors)],
        dtype=np.uint8,
    )


# ── Main ───────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Monte Carlo test for pattern randomness"
    )
    parser.add_argument(
        "--matrix", default="output/matrix.txt", help="Path to extracted matrix"
    )
    parser.add_argument(
        "--n-samples", type=int, default=999, help="Number of random samples"
    )
    parser.add_argument(
        "--tile-size", type=int, default=6, help="Rendered tile size in pixels"
    )
    parser.add_argument(
        "--mortar", type=int, default=1, help="Mortar line width in pixels"
    )
    args = parser.parse_args()

    # ── Load original ──────────────────────────────────────────────
    original = load_matrix(args.matrix)
    rows, cols = original.shape
    n_colors = int(original.max()) + 1
    palette = make_palette(n_colors)

    orig_counts = np.bincount(original.ravel(), minlength=n_colors)
    orig_probs = orig_counts / orig_counts.sum()

    print(f"Original pattern: {rows}x{cols}, {n_colors} colors")
    print(f"  Color distribution: {dict(zip(range(n_colors), orig_counts))}")
    print(
        f"  Color probabilities: {dict(zip(range(n_colors), np.round(orig_probs, 3)))}"
    )
    print(f"  Samples: {args.n_samples}\n")

    # ── Compute original metrics ──────────────────────────────────
    orig_mi = mutual_info(original)
    orig_moran = morans_i(original)
    orig_runs = runs_ratio(original)
    orig_ent = entropy(original)

    print("Original metrics:")
    print(f"  Moran's I        = {orig_moran:.4f}")
    print(f"  Mutual Info      = {orig_mi:.4f}")
    print(f"  Runs Ratio       = {orig_runs:.4f}")
    print(f"  Normalized Entropy = {orig_ent:.4f}")
    print()

    # ── Monte Carlo ────────────────────────────────────────────────
    print(f"Generating {args.n_samples} random patterns...")
    results = {"moran": [], "mi": [], "runs": [], "ent": []}

    for s in range(args.n_samples):
        mat = gen_random_with_probs(rows, cols, orig_probs)
        results["moran"].append(morans_i(mat))
        results["mi"].append(mutual_info(mat))
        results["runs"].append(runs_ratio(mat))
        results["ent"].append(entropy(mat))
        if (s + 1) % 200 == 0:
            print(f"  ... {s + 1}/{args.n_samples}")

    # ── Empirical p-values ─────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  EMPIRICAL P-VALUES (matched color distribution)")
    print("=" * 70)

    for metric_name, orig_val, key, side in [
        ("Moran's I", orig_moran, "moran", "upper"),
        ("Mutual Info", orig_mi, "mi", "upper"),
        ("Runs Ratio", orig_runs, "runs", "lower"),
        ("Entropy", orig_ent, "ent", "upper"),
    ]:
        arr = np.array(results[key])
        p_val = (
            (arr >= orig_val).mean() if side == "upper" else (arr <= orig_val).mean()
        )
        mean_val = arr.mean()
        std_val = arr.std()
        z_score = (orig_val - mean_val) / std_val if std_val > 0 else 0
        print(
            f"  {metric_name:<16}  orig={orig_val:.4f}  "
            f"mean={mean_val:.4f}  std={std_val:.4f}  "
            f"z={z_score:+.2f}  p({side})={p_val:.4f}"
        )

    print("=" * 70)
    print()

    # ── Visual comparison (original vs 11 random samples, with mortar) ──
    print("Generating visual comparison (with mortar borders, original size)...")
    fig, axes = plt.subplots(3, 4, figsize=(14, 10))
    axes_flat = axes.ravel()

    # Original
    ax = axes_flat[0]
    orig_img = render_with_mortar(original, palette, args.tile_size, args.mortar)
    ax.imshow(orig_img)
    ax.set_title("Original", fontsize=12, fontweight="bold")
    ax.axis("off")
    ax.text(
        0.5,
        -0.05,
        f"I={orig_moran:.3f}  MI={orig_mi:.3f}  Runs={orig_runs:.2f}",
        transform=ax.transAxes,
        ha="center",
        fontsize=8,
    )

    # 11 random samples (all 47x78, same as original)
    rng_vis = np.random.default_rng(12345)
    for idx in range(1, 12):
        ax = axes_flat[idx]
        mat = rng_vis.choice(n_colors, size=(rows, cols), p=orig_probs).astype(int)
        img = render_with_mortar(mat, palette, args.tile_size, args.mortar)
        ax.imshow(img)
        mi_v = mutual_info(mat)
        moran_v = morans_i(mat)
        runs_v = runs_ratio(mat)
        ax.set_title(f"Random #{idx}  I={moran_v:.3f} MI={mi_v:.3f}", fontsize=9)
        ax.axis("off")

    for idx in range(12, len(axes_flat)):
        axes_flat[idx].axis("off")

    plt.suptitle(
        "Visual Comparison: Original vs. Random Samples (matched color distribution)\n"
        f"All at {rows}x{cols} with mortar borders",
        fontsize=14,
        fontweight="bold",
        y=1.02,
    )
    plt.tight_layout()
    plt.savefig("output/monte_carlo_visual.png", dpi=150, bbox_inches="tight")
    print("Saved output/monte_carlo_visual.png")

    # ── Histograms ──────────────────────────────────────────────────
    print("Generating metric distribution plots...")
    fig2, axes2 = plt.subplots(2, 2, figsize=(12, 10))
    metrics_data = [
        ("Moran's I", results["moran"], orig_moran, "higher = more clustering"),
        ("Mutual Information", results["mi"], orig_mi, "higher = more structure"),
        ("Runs Ratio", results["runs"], orig_runs, "lower = more clustering"),
        ("Normalized Entropy", results["ent"], orig_ent, "lower = less uniform"),
    ]

    for ax, (name, vals, orig_val, note) in zip(axes2.ravel(), metrics_data):
        ax.hist(
            vals, bins=40, color="#4a8a5c", alpha=0.7, edgecolor="white", linewidth=0.5
        )
        ax.axvline(
            orig_val,
            color="red",
            linewidth=2.5,
            linestyle="--",
            label=f"Original ({orig_val:.3f})",
        )
        ax.set_title(name, fontsize=13, fontweight="bold")
        ax.set_xlabel(note, fontsize=9)
        ax.set_ylabel("Frequency")
        ax.legend(fontsize=9)
        pct = (1 - (np.array(vals) < orig_val).mean()) * 100
        if name == "Runs Ratio":
            pct = (np.array(vals) > orig_val).mean() * 100
        ax.text(
            0.97,
            0.95,
            f"original > {100 - pct:.1f}% of randoms",
            transform=ax.transAxes,
            ha="right",
            va="top",
            fontsize=9,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8),
        )

    plt.suptitle(
        "Monte Carlo Test: Metric Distributions Under Pure Randomness\n"
        f"({args.n_samples} samples, {rows}x{cols}, {n_colors} colors, matched probabilities)",
        fontsize=13,
        fontweight="bold",
        y=1.02,
    )
    plt.tight_layout()
    plt.savefig("output/monte_carlo_histograms.png", dpi=150, bbox_inches="tight")
    print("Saved output/monte_carlo_histograms.png")

    # ── Color count hypothesis test ──────────────────────────────────
    print("\n" + "=" * 70)
    print("  COLOR COUNT HYPOTHESIS TEST")
    print("  Does fewer colors make random patterns look more clustered?")
    print("=" * 70)

    n_samples_cc = min(args.n_samples, 499)
    color_counts = [2, 3, 4, 5, 6, 8, 10, 15]
    cc_results = {
        "n_colors": color_counts,
        "mean_moran": [],
        "mean_mi": [],
        "std_moran": [],
        "std_mi": [],
    }

    print(f"\n  Generating {n_samples_cc} samples per color count...")
    for nc in color_counts:
        moran_vals = [
            morans_i(gen_random_with_probs(rows, cols, np.ones(nc) / nc))
            for _ in range(n_samples_cc)
        ]
        mi_vals = [
            mutual_info(gen_random_with_probs(rows, cols, np.ones(nc) / nc))
            for _ in range(n_samples_cc)
        ]
        cc_results["mean_moran"].append(np.mean(moran_vals))
        cc_results["mean_mi"].append(np.mean(mi_vals))
        cc_results["std_moran"].append(np.std(moran_vals))
        cc_results["std_mi"].append(np.std(mi_vals))
        print(
            f"    {nc:2d} colors:  Moran I = {np.mean(moran_vals):.4f} +/- {np.std(moran_vals):.4f}  "
            f"MI = {np.mean(mi_vals):.4f} +/- {np.std(mi_vals):.4f}"
        )

    # Plot
    fig3, axes3 = plt.subplots(1, 2, figsize=(12, 4.5))
    for ax, means, stds, ylabel, title in [
        (
            axes3[0],
            cc_results["mean_moran"],
            cc_results["std_moran"],
            "Mean Moran's I",
            "Moran's I vs. Color Count",
        ),
        (
            axes3[1],
            cc_results["mean_mi"],
            cc_results["std_mi"],
            "Mean Mutual Info",
            "Mutual Info vs. Color Count",
        ),
    ]:
        ax.errorbar(
            cc_results["n_colors"],
            means,
            yerr=stds,
            fmt="-o",
            color="#2d6633",
            capsize=4,
            capthick=1.5,
            linewidth=2,
        )
        ax.set_title(title, fontsize=12, fontweight="bold")
        ax.set_xlabel("Number of colors")
        ax.set_ylabel(ylabel)
        ax.axhline(y=0, color="gray", linestyle="--", alpha=0.5)

    plt.suptitle(
        "Does Color Count Affect Randomness Metrics?", fontsize=13, fontweight="bold"
    )
    plt.tight_layout()
    plt.savefig("output/monte_carlo_color_count.png", dpi=150, bbox_inches="tight")
    print("Saved output/monte_carlo_color_count.png")

    # ── Color distribution skew test ──────────────────────────────────
    print("\n" + "=" * 70)
    print("  COLOR DISTRIBUTION SKEW TEST")
    print("  Does a non-uniform color distribution inflate spatial metrics?")
    print("=" * 70)

    # Compare uniform vs matched random (same n_colors=5)
    n_skew = min(args.n_samples, 499)
    uni_moran = []
    uni_mi = []
    for _ in range(n_skew):
        mat_u = gen_random_with_probs(rows, cols, np.ones(n_colors) / n_colors)
        uni_moran.append(morans_i(mat_u))
        uni_mi.append(mutual_info(mat_u))

    print(f"\n  {n_skew} samples each, {n_colors} colors:")
    print(f"    Uniform distribution:")
    print(f"      Moran's I = {np.mean(uni_moran):.4f} +/- {np.std(uni_moran):.4f}")
    print(f"      MI        = {np.mean(uni_mi):.4f} +/- {np.std(uni_mi):.4f}")
    print(f"    Matched (original's) distribution:")
    print(
        f"      Moran's I = {np.mean(results['moran'][:n_skew]):.4f} +/- {np.std(results['moran'][:n_skew]):.4f}"
    )
    print(
        f"      MI        = {np.mean(results['mi'][:n_skew]):.4f} +/- {np.std(results['mi'][:n_skew]):.4f}"
    )
    print(f"    Original photo:")
    print(f"      Moran's I = {orig_moran:.4f}")
    print(f"      MI        = {orig_mi:.4f}")

    if abs(np.mean(uni_moran) - np.mean(results["moran"][:n_skew])) < 0.005:
        print(
            f"\n  => Color distribution skew has NEGLIGIBLE effect on spatial metrics."
        )
        print(
            f"  => The original's clustering (I={orig_moran:.3f}) is NOT explained by"
        )
        print(f"     its non-uniform color distribution.")
    else:
        print(
            f"\n  => Color distribution skew has a measurable effect on spatial metrics."
        )
        print(f"  => However, the original's I={orig_moran:.3f} is still far from")
        print(f"     the random baseline (~{np.mean(uni_moran):.3f}).")

    # ── Final verdict ────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  FINAL VERDICT")
    print("=" * 70)

    p_moran = (np.array(results["moran"]) >= orig_moran).mean()
    p_mi = (np.array(results["mi"]) >= orig_mi).mean()
    p_runs = (np.array(results["runs"]) <= orig_runs).mean()

    print(f"\n  Moran's I p-value (upper-tail) : {p_moran:.4f}")
    print(f"  Mutual Info p-value (upper-tail): {p_mi:.4f}")
    print(f"  Runs Ratio p-value (lower-tail) : {p_runs:.4f}")
    print()

    significant = sum(p < 0.05 for p in [p_moran, p_mi, p_runs])
    if significant >= 2:
        print("  CONCLUSION: The original pattern is SIGNIFICANTLY different")
        print("  from pure random (p < 0.05 on multiple metrics).")
        print("  The apparent clustering is NOT just an artifact of few colors")
        print("  or non-uniform color distribution.")
    elif significant >= 1:
        print("  CONCLUSION: There is WEAK EVIDENCE that the original pattern")
        print("  differs from pure random (one metric significant).")
    else:
        print("  CONCLUSION: The original pattern is CONSISTENT with pure random.")
        print("  The apparent clustering may be a visual illusion.")

    print("\n  Regarding the color count hypothesis:")
    print(
        f"  - Even with 2 colors, random patterns have Moran's I ~ {cc_results['mean_moran'][0]:.3f}"
    )
    print(f"  - The original Moran's I = {orig_moran:.3f}")
    print("  - So the original's clustering is NOT explained by color count alone.")

    print("\n  Regarding the color distribution skew:")
    print(f"  - Uniform random Moran's I ~ {np.mean(uni_moran):.3f}")
    print(f"  - Matched random Moran's I  ~ {np.mean(results['moran'][:n_skew]):.3f}")
    print(f"  - Original Moran's I        = {orig_moran:.3f}")
    print(
        "  - The original's non-uniform color distribution does NOT cause its clustering."
    )
    print("=" * 70)


if __name__ == "__main__":
    main()
