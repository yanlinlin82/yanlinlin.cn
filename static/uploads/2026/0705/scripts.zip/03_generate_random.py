"""
Script 3: Generate Pure Random Pattern
=======================================
Generate a completely random tile pattern (i.i.d. uniform).
Each tile's color is chosen independently of its neighbors.

Rendered with mortar-style borders to match the original photo's style.

Usage:
    uv run python scripts/03_generate_random.py [--rows 30] [--cols 40] [--colors 5]

Output:
    - output/random_pattern.png      : visualization (with mortar borders)
    - output/random_matrix.txt       : the tile matrix
"""

import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")


def generate_random(
    rows: int, cols: int, n_colors: int, seed: int = None
) -> np.ndarray:
    """Generate a completely random tile matrix."""
    rng = np.random.default_rng(seed)
    return rng.integers(0, n_colors, size=(rows, cols))


def make_palette(n_colors: int) -> np.ndarray:
    """Create a pleasant color palette for visualization."""
    palettes = {
        3: [(34, 139, 34), (107, 142, 35), (154, 205, 50)],
        4: [(25, 65, 20), (50, 100, 45), (90, 145, 80), (140, 185, 130)],
        5: [(25, 41, 16), (41, 57, 31), (59, 82, 47), (76, 103, 64), (118, 154, 122)],
        6: [
            (25, 41, 16),
            (41, 57, 31),
            (59, 82, 47),
            (76, 103, 64),
            (100, 130, 100),
            (140, 175, 140),
        ],
    }
    if n_colors in palettes:
        return np.array(palettes[n_colors], dtype=np.uint8)
    cmap = plt.get_cmap("Greens")
    return np.array(
        [np.array(cmap(i / (n_colors - 1))[:3]) * 255 for i in range(n_colors)],
        dtype=np.uint8,
    )


def render_with_mortar(
    matrix: np.ndarray,
    palette: np.ndarray,
    tile_size: int = 10,
    mortar_width: int = 2,
    mortar_color=(20, 25, 18),
) -> np.ndarray:
    """Render a tile matrix as an image with mortar-style borders between tiles.

    Each tile becomes a ``tile_size`` x ``tile_size`` colored square.
    The dark mortar runs between tiles, mimicking the original photo.
    """
    rows, cols = matrix.shape
    img_h = rows * tile_size + (rows + 1) * mortar_width
    img_w = cols * tile_size + (cols + 1) * mortar_width
    img = np.full((img_h, img_w, 3), list(mortar_color), dtype=np.uint8)
    for i in range(rows):
        for j in range(cols):
            y = i * (tile_size + mortar_width) + mortar_width
            x = j * (tile_size + mortar_width) + mortar_width
            img[y : y + tile_size, x : x + tile_size] = palette[matrix[i, j]]
    return img


def main():
    parser = argparse.ArgumentParser(description="Generate pure random tile pattern")
    parser.add_argument("--rows", type=int, default=30, help="Number of rows")
    parser.add_argument("--cols", type=int, default=40, help="Number of columns")
    parser.add_argument("--colors", type=int, default=5, help="Number of colors")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument(
        "--tile-size", type=int, default=10, help="Rendered tile size in pixels"
    )
    parser.add_argument(
        "--mortar", type=int, default=2, help="Mortar line width in pixels"
    )
    args = parser.parse_args()

    print(
        f"Generating {args.rows}x{args.cols} random pattern with {args.colors} colors..."
    )
    matrix = generate_random(args.rows, args.cols, args.colors, seed=args.seed)
    palette = make_palette(args.colors)

    # Save matrix
    np.savetxt("output/random_matrix.txt", matrix, fmt="%d")
    print("Saved output/random_matrix.txt")

    # Render with mortar borders and save
    image = render_with_mortar(matrix, palette, args.tile_size, args.mortar)
    fig, ax = plt.subplots(1, 1, figsize=(10, 8))
    ax.imshow(image)
    ax.set_title(
        f"Pure Random Pattern ({args.rows}x{args.cols}, {args.colors} colors)",
        fontsize=12,
    )
    ax.axis("off")
    plt.tight_layout()
    plt.savefig("output/random_pattern.png", dpi=150, bbox_inches="tight")
    print("Saved output/random_pattern.png")

    # Print summary
    print(f"\nColor distribution (counts):")
    for i in range(args.colors):
        count = (matrix == i).sum()
        print(f"  Color {i}: {count:4d} tiles ({100 * count / matrix.size:.1f}%)")

    print(f"\nPreview (first 10x10):")
    for row in matrix[:10, :10]:
        print("  " + " ".join(str(c) for c in row))


if __name__ == "__main__":
    main()
