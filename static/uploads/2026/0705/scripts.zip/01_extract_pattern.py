"""
Script 1: Extract Pattern from Image
======================================
Reads a photo of mosaic tiles, quantizes colors, detects the grid,
and outputs a 2D matrix representing the tile pattern.

Usage:
    uv run python scripts/01_extract_pattern.py [--image path] [--n-colors N]

Output:
    - output/matrix.txt         : the extracted tile matrix (integer labels)
    - output/palette.txt        : the color palette (RGB)
    - output/extraction_*.png   : visualizations of the extraction process
"""

import argparse
import warnings

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from sklearn.cluster import KMeans

matplotlib.use("Agg")
warnings.filterwarnings("ignore", category=UserWarning)


def load_image(path: str) -> np.ndarray:
    img = Image.open(path).convert("RGB")
    return np.array(img)


def quantize_colors(arr: np.ndarray, n_colors: int, seed: int = 42) -> tuple:
    """K-means quantization to reduce image to a small color palette."""
    h, w = arr.shape[:2]
    pixels = arr.reshape(-1, 3)
    kmeans = KMeans(n_clusters=n_colors, random_state=seed, n_init=5)
    labels = kmeans.fit_predict(pixels)
    palette = kmeans.cluster_centers_.astype(np.uint8)
    quantized = palette[labels].reshape(h, w, 3)
    label_map = labels.reshape(h, w)
    return quantized, label_map, palette


def detect_grid_period(gray: np.ndarray) -> tuple:
    """Detect tile grid period using autocorrelation of row/column projections.

    Instead of finding individual mortar lines (which is fragile with real-world
    photos that have lighting variation and perspective), we find the *dominant
    period* of the grid and then place grid lines at regular intervals.

    Returns
    -------
    n_rows, n_cols : number of tiles in each dimension
    tile_h, tile_w : tile height and width in pixels
    """
    h, w = gray.shape

    row_proj = gray.mean(axis=1)
    col_proj = gray.mean(axis=0)

    # Subtract mean to remove DC component
    row_proj = row_proj - row_proj.mean()
    col_proj = col_proj - col_proj.mean()

    # Autocorrelation via FFT (much faster than direct)
    def find_period(signal: np.ndarray, max_period: int = 200) -> int:
        """Find the dominant period in a 1D signal using autocorrelation."""
        n = len(signal)
        # FFT-based autocorrelation
        from scipy.signal import correlate

        ac = correlate(signal, signal, mode="same", method="fft")
        # Look at positive lags only (right half)
        mid = n // 2
        ac_right = ac[mid : mid + min(max_period, n // 2)]
        # Skip lag 0 (trivial peak) - start from lag 2 to avoid edge effects
        start = 2
        if len(ac_right) <= start:
            return max(1, n // 30)
        segment = ac_right[start:]
        if segment.max() <= 0:
            return max(1, n // 30)
        # Find the first significant peak
        from scipy.signal import find_peaks

        peaks, props = find_peaks(segment, height=segment.max() * 0.3, distance=3)
        if len(peaks) > 0:
            return start + peaks[0]
        # Fallback: return 1/30 of total length
        return max(1, n // 30)

    tile_h = find_period(row_proj)
    tile_w = find_period(col_proj)

    n_rows = max(1, h // tile_h)
    n_cols = max(1, w // tile_w)

    return n_rows, n_cols, tile_h, tile_w


def detect_rotation_angle(
    gray: np.ndarray, angle_range: float = 5.0, step: float = 0.2
) -> float:
    """Detect the rotation angle of the tile grid in a photo.

    The idea: when the image is correctly deskewed (grid lines aligned with
    axes), the row projection has the strongest periodic signal (sharpest
    autocorrelation peak).  We search over a range of rotation angles and
    pick the one that maximizes this peak.
    """
    from scipy import ndimage as ndi
    from scipy.signal import correlate, find_peaks

    h, w = gray.shape
    # Crop center portion to avoid edge artifacts from rotation
    center = gray[h // 4 : 3 * h // 4, w // 4 : 3 * w // 4]

    def alignment_score(img: np.ndarray) -> float:
        """Score how well grid lines align with axes.

        Higher score = better alignment (sharper autocorrelation peak).
        """
        proj = img.mean(axis=1)  # row projection
        proj = proj - proj.mean()
        n = len(proj)
        ac = correlate(proj, proj, mode="same", method="fft")
        mid = n // 2
        ac_right = ac[mid + 2 : mid + min(100, n // 2)]
        if ac_right.max() <= 0:
            return 0.0
        # Find the peak height relative to neighbors (sharpness)
        peaks, props = find_peaks(ac_right, height=ac_right.max() * 0.3, distance=3)
        if len(peaks) == 0:
            return 0.0
        # Score = peak height at first significant peak
        return float(props["peak_heights"][0])

    angles = np.arange(-angle_range, angle_range + step, step)
    best_angle = 0.0
    best_score = alignment_score(center)

    for angle in angles:
        if angle == 0.0:
            continue
        rotated = ndi.rotate(center, angle, reshape=False, order=1, mode="reflect")
        score = alignment_score(rotated)
        if score > best_score:
            best_score = score
            best_angle = angle

    return best_angle


def extract_with_regular_grid(
    label_map: np.ndarray, n_rows: int, n_cols: int
) -> np.ndarray:
    """Extract tile matrix by imposing a regular grid of n_rows x n_cols.

    Each tile is a rectangular region, and its color is determined by
    majority vote of the quantized labels within that region.
    Ignores negative label values (border padding from deskew).
    """
    h, w = label_map.shape
    row_edges = np.linspace(0, h, n_rows + 1, dtype=int)
    col_edges = np.linspace(0, w, n_cols + 1, dtype=int)

    matrix = np.zeros((n_rows, n_cols), dtype=int)
    for i in range(n_rows):
        for j in range(n_cols):
            tile = label_map[
                row_edges[i] : row_edges[i + 1], col_edges[j] : col_edges[j + 1]
            ]
            # Count only non-negative labels (ignore -1 border padding)
            valid = tile[tile >= 0]
            if len(valid) == 0:
                matrix[i, j] = 0
            else:
                matrix[i, j] = np.bincount(valid.ravel()).argmax()
    return matrix


def extract_with_fixed_grid(
    label_map: np.ndarray, tile_size_row: int, tile_size_col: int
) -> np.ndarray:
    """Extract tile matrix by imposing a regular grid of given tile size.

    Used as fallback when automatic grid detection is unreliable.
    """
    h, w = label_map.shape
    n_rows = h // tile_size_row
    n_cols = w // tile_size_col

    matrix = np.zeros((n_rows, n_cols), dtype=int)
    for i in range(n_rows):
        for j in range(n_cols):
            r_start, r_end = i * tile_size_row, (i + 1) * tile_size_row
            c_start, c_end = j * tile_size_col, (j + 1) * tile_size_col
            tile = label_map[r_start:r_end, c_start:c_end]
            matrix[i, j] = np.bincount(tile.ravel()).argmax()

    return matrix


def main():
    parser = argparse.ArgumentParser(description="Extract tile pattern from image")
    parser.add_argument("--image", default="pattern.png", help="Path to input image")
    parser.add_argument(
        "--n-colors", type=int, default=5, help="Number of colors in palette"
    )
    parser.add_argument(
        "--tile-size",
        type=int,
        default=None,
        help="Force tile size in pixels (auto-detect if not set)",
    )
    parser.add_argument(
        "--rows",
        type=int,
        default=None,
        help="Manually specify number of tile rows (overrides auto-detect)",
    )
    parser.add_argument(
        "--cols",
        type=int,
        default=None,
        help="Manually specify number of tile columns (overrides auto-detect)",
    )
    args = parser.parse_args()

    print(f"[1/4] Loading image: {args.image}")
    arr = load_image(args.image)
    h, w = arr.shape[:2]
    print(f"       Image size: {w}x{h}")

    print(f"[2/4] Quantizing to {args.n_colors} colors...")
    quantized, label_map, palette = quantize_colors(arr, args.n_colors)
    print("       Color palette (RGB):")
    for i, c in enumerate(palette):
        print(f"         {i}: RGB({c[0]}, {c[1]}, {c[2]})")

    print("[3/5] Detecting rotation angle...")
    gray = np.mean(arr, axis=2)
    angle = detect_rotation_angle(gray)
    print(f"       Detected rotation: {angle:+.2f} deg")

    print("[4/5] Deskewing image...")
    from scipy import ndimage as ndi

    if abs(angle) > 0.1:
        # Rotate the full image and the label map
        arr_rot = ndi.rotate(arr, angle, reshape=True, order=1, mode="constant", cval=0)
        label_map_rot = ndi.rotate(
            label_map.astype(float),
            angle,
            reshape=True,
            order=0,
            mode="constant",
            cval=-1,
        ).astype(int)
        # Crop to remove blank corners (find the largest central rectangle)
        # Use the label_map with cval=-1 to find valid region
        mask_valid = label_map_rot >= 0
        rows_valid = np.any(mask_valid, axis=1)
        cols_valid = np.any(mask_valid, axis=0)
        r_min, r_max = np.where(rows_valid)[0][[0, -1]]
        c_min, c_max = np.where(cols_valid)[0][[0, -1]]
        # Add a small margin to avoid edge artifacts
        margin = 5
        r_min, r_max = r_min + margin, r_max - margin
        c_min, c_max = c_min + margin, c_max - margin
        arr_rot = arr_rot[r_min : r_max + 1, c_min : c_max + 1]
        label_map_rot = label_map_rot[r_min : r_max + 1, c_min : c_max + 1]
        print(f"       Deskewed size: {arr_rot.shape[1]}x{arr_rot.shape[0]}")
    else:
        arr_rot = arr
        label_map_rot = label_map
        print(f"       Negligible rotation (< 0.1 deg), skipping deskew")

    print("[5/5] Extracting tile grid...")
    gray_rot = np.mean(arr_rot, axis=2)
    if args.rows is not None and args.cols is not None:
        n_rows, n_cols = args.rows, args.cols
        tile_matrix = extract_with_regular_grid(label_map_rot, n_rows, n_cols)
        grid_info = f"manual: {n_rows}x{n_cols}"
    elif args.tile_size is not None:
        n_rows = arr_rot.shape[0] // args.tile_size
        n_cols = arr_rot.shape[1] // args.tile_size
        tile_matrix = extract_with_regular_grid(label_map_rot, n_rows, n_cols)
        grid_info = f"tile size {args.tile_size}px: {n_rows}x{n_cols}"
    else:
        n_rows, n_cols, tile_h, tile_w = detect_grid_period(gray_rot)
        tile_matrix = extract_with_regular_grid(label_map_rot, n_rows, n_cols)
        grid_info = f"auto-detect period ~{tile_h}x{tile_w}px: {n_rows}x{n_cols}"
    print(f"       Grid: {grid_info}")

    print(
        f"       Tile matrix shape: {tile_matrix.shape[0]} rows x {tile_matrix.shape[1]} cols"
    )

    print("[6/6] Saving outputs...")
    # Save tile matrix
    np.savetxt("output/matrix.txt", tile_matrix, fmt="%d")
    # Save palette
    np.savetxt("output/palette.txt", palette, fmt="%d")

    # Print matrix preview
    print("\nTile matrix preview (first 10x10):")
    preview = tile_matrix[
        : min(10, tile_matrix.shape[0]), : min(10, tile_matrix.shape[1])
    ]
    for row in preview:
        print("  " + " ".join(str(int(c)) for c in row))

    # Also save a clean reconstructed image from the matrix
    reconstructed = palette[tile_matrix]
    Image.fromarray(reconstructed).save("output/extraction_reconstructed.png")

    # Save diagnostic figure
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))

    axes[0, 0].imshow(arr)
    axes[0, 0].set_title(f"Original ({w}x{h})", fontsize=10)
    axes[0, 0].axis("off")

    axes[0, 1].imshow(quantized)
    axes[0, 1].set_title(f"Quantized ({args.n_colors} colors)", fontsize=10)
    axes[0, 1].axis("off")

    axes[0, 2].imshow(arr_rot.astype(np.uint8))
    axes[0, 2].set_title(
        f"Deskewed ({angle:+.2f} deg, {arr_rot.shape[1]}x{arr_rot.shape[0]})",
        fontsize=10,
    )
    axes[0, 2].axis("off")

    # Grid overlay on deskewed image
    axes[1, 0].imshow(arr_rot.astype(np.uint8))
    gh, gw = gray_rot.shape
    for i in range(1, tile_matrix.shape[0]):
        y = int(i * gh / tile_matrix.shape[0])
        axes[1, 0].axhline(y, color="red", alpha=0.5, linewidth=0.5)
    for j in range(1, tile_matrix.shape[1]):
        x = int(j * gw / tile_matrix.shape[1])
        axes[1, 0].axvline(x, color="red", alpha=0.5, linewidth=0.5)
    axes[1, 0].set_title(
        f"Grid: {tile_matrix.shape[0]} rows x {tile_matrix.shape[1]} cols", fontsize=10
    )
    axes[1, 0].axis("off")

    axes[1, 1].imshow(reconstructed)
    axes[1, 1].set_title(
        f"Reconstructed ({tile_matrix.shape[0]}\u00d7{tile_matrix.shape[1]})",
        fontsize=10,
    )
    axes[1, 1].axis("off")

    # Color bars
    color_bar = np.zeros((30, 150, 3), dtype=np.uint8)
    seg_w = 150 // args.n_colors
    for i in range(args.n_colors):
        color_bar[:, i * seg_w : (i + 1) * seg_w] = palette[i]
    axes[1, 2].imshow(color_bar)
    axes[1, 2].set_title("Color Palette", fontsize=10)
    axes[1, 2].axis("off")
    for i in range(args.n_colors):
        axes[1, 2].text(
            i * seg_w + seg_w // 2 - 3,
            15,
            str(i),
            color="white",
            fontsize=8,
            ha="center",
            va="center",
            fontweight="bold",
        )

    # Also save the deskewed image for reference
    Image.fromarray(arr_rot.astype(np.uint8)).save("output/extraction_deskewed.png")

    plt.tight_layout()
    plt.savefig("output/extraction_diagnostic.png", dpi=150, bbox_inches="tight")
    print("\nSaved:")
    print("  output/matrix.txt")
    print("  output/palette.txt")
    print("  output/extraction_reconstructed.png")
    print("  output/extraction_diagnostic.png")

    # Final summary
    print("\n--- Color distribution in extracted matrix ---")
    for i in range(args.n_colors):
        count = (tile_matrix == i).sum()
        pct = 100 * count / tile_matrix.size
        print(
            f"  Color {i} RGB({palette[i, 0]},{palette[i, 1]},{palette[i, 2]}): {count} tiles ({pct:.1f}%)"
        )


if __name__ == "__main__":
    main()
