"""
Script 2: Evaluate Randomness
==============================
Apply multiple statistical tests to judge whether a tile matrix
is "completely random" (i.i.d.) or has spatial structure.

Tests performed:
  1. Chi-square test       -- are color frequencies uniform?
  2. Shannon entropy       -- information content of color distribution
  3. Moran's I             -- spatial autocorrelation (clustering)
  4. 2D Runs test          -- are same-color tiles clumped?
  5. Mutual Information    -- dependence between neighboring tiles

Usage:
    uv run python scripts/02_eval_randomness.py [--matrix output/matrix.txt]

Output:
    - Printed test results with interpretations
"""

import argparse

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import chi2_contingency, norm

matplotlib.use("Agg")


def load_matrix(path: str) -> np.ndarray:
    return np.loadtxt(path, dtype=int)


# ── 1. Chi-square test for uniformity ──────────────────────────────────


def chi_square_uniformity(matrix: np.ndarray) -> dict:
    """Test if all colors appear equally often."""
    counts = np.bincount(matrix.ravel())
    expected = matrix.size / len(counts)
    chi2 = np.sum((counts - expected) ** 2 / expected)
    df = len(counts) - 1
    # Approximate p-value from chi-square distribution
    from scipy.stats import chi2 as chi2_dist

    p = 1 - chi2_dist.cdf(chi2, df)
    return {
        "chi2_stat": chi2,
        "df": df,
        "p_value": p,
        "counts": counts.tolist(),
        "is_significant": p < 0.05,
        "interpretation": (
            "Colors are NOT uniformly distributed (p < 0.05)"
            if p < 0.05
            else "Color frequencies are consistent with uniformity (p >= 0.05)"
        ),
    }


# ── 2. Shannon entropy ────────────────────────────────────────────────


def shannon_entropy(matrix: np.ndarray) -> dict:
    """Compute H = -sum(p * log2(p)).  Max when all colors equally likely."""
    counts = np.bincount(matrix.ravel())
    probs = counts[counts > 0] / matrix.size
    h = -np.sum(probs * np.log2(probs))
    n_colors = len(counts)
    h_max = np.log2(n_colors)
    return {
        "entropy": h,
        "max_entropy": h_max,
        "normalized_entropy": h / h_max if h_max > 0 else 0,
        "interpretation": (
            f"H = {h:.3f} / {h_max:.3f}  ({100 * h / h_max:.1f}% of maximum)"
            if h_max > 0
            else "Single color -- zero entropy"
        ),
    }


# ── 3. Moran's I (spatial autocorrelation) ────────────────────────────


def morans_i(matrix: np.ndarray) -> dict:
    """Moran's I measures spatial clustering.

    I > 0   -> positive autocorrelation (clustering)
    I ~ 0   -> random spatial arrangement
    I < 0   -> negative autocorrelation (checkerboard)
    """
    n = matrix.size
    # Use numerical labels directly
    z = matrix.ravel().astype(float)
    z_bar = z.mean()
    z_dev = z - z_bar

    # Sum of squared deviations
    s2 = np.sum(z_dev**2) / n

    # Spatial weights: rook adjacency (4-neighbor)
    h, w = matrix.shape
    total_weight = 0.0
    weighted_cov = 0.0

    for i in range(h):
        for j in range(w):
            idx = i * w + j
            neighbors = []
            if i > 0:
                neighbors.append((i - 1, j))
            if i < h - 1:
                neighbors.append((i + 1, j))
            if j > 0:
                neighbors.append((i, j - 1))
            if j < w - 1:
                neighbors.append((i, j + 1))

            for ni, nj in neighbors:
                nidx = ni * w + nj
                weighted_cov += z_dev[idx] * z_dev[nidx]
                total_weight += 1.0

    if total_weight == 0 or s2 == 0:
        return {"morans_i": 0, "interpretation": "Cannot compute (constant matrix)"}

    i_stat = (n / total_weight) * (weighted_cov / (n * s2))

    # Expected value under no spatial autocorrelation
    expected_i = -1.0 / (n - 1)

    # Simple interpretation
    if abs(i_stat) < 0.1:
        interp = "Near zero -- no spatial autocorrelation (random arrangement)"
    elif i_stat > 0:
        interp = f"Positive ({i_stat:.3f}) -- colors tend to cluster"
    else:
        interp = (
            f"Negative ({i_stat:.3f}) -- colors tend to alternate (checkerboard-like)"
        )

    return {
        "morans_i": i_stat,
        "expected_i": expected_i,
        "interpretation": interp,
    }


# ── 4. 2D Runs test ──────────────────────────────────────────────────


def runs_test_2d(matrix: np.ndarray) -> dict:
    """Count "runs" (contiguous same-color blocks) horizontally and vertically.

    Fewer runs than expected under independence => clustering.
    """
    h, w = matrix.shape

    # Horizontal runs
    h_runs = 0
    for i in range(h):
        for j in range(1, w):
            if matrix[i, j] != matrix[i, j - 1]:
                h_runs += 1

    # Vertical runs
    v_runs = 0
    for j in range(w):
        for i in range(1, h):
            if matrix[i, j] != matrix[i - 1, j]:
                v_runs += 1

    total_runs = h_runs + v_runs

    # Expected number of transitions under independence
    # For each adjacent pair, P(same) = sum(p_k^2) where p_k = proportion of color k
    counts = np.bincount(matrix.ravel())
    probs = counts / matrix.size
    p_same = np.sum(probs**2)

    expected_h_runs = (h * (w - 1)) * (1 - p_same)
    expected_v_runs = (w * (h - 1)) * (1 - p_same)
    expected_total = expected_h_runs + expected_v_runs

    # Interpret: fewer transitions = more clustering
    ratio = total_runs / expected_total if expected_total > 0 else 1.0

    if ratio < 0.9:
        interp = f"FEWER runs than expected ({ratio:.2f}x) -- colors are CLUSTERED"
    elif ratio > 1.1:
        interp = f"MORE runs than expected ({ratio:.2f}x) -- colors tend to alternate"
    else:
        interp = (
            f"Run count near expectation ({ratio:.2f}x) -- consistent with randomness"
        )

    return {
        "horizontal_runs": h_runs,
        "vertical_runs": v_runs,
        "total_runs": total_runs,
        "expected_horizontal": expected_h_runs,
        "expected_vertical": expected_v_runs,
        "expected_total": expected_total,
        "ratio": ratio,
        "interpretation": interp,
    }


# ── 5. Mutual Information (adjacent pixels) ──────────────────────────


def mutual_information_neighbor(matrix: np.ndarray) -> dict:
    """Compute I(X; Y) between a pixel and its right neighbor.

    I = 0  => independent (random)
    I > 0  => dependence (structure)
    """
    h, w = matrix.shape

    # Build joint distribution of (pixel, right neighbor)
    pairs = []
    for i in range(h):
        for j in range(w - 1):
            pairs.append((matrix[i, j], matrix[i, j + 1]))
    pairs = np.array(pairs)

    n = len(pairs)
    if n == 0:
        return {"mutual_information": 0, "interpretation": "No data"}

    n_colors = int(matrix.max()) + 1
    joint = np.zeros((n_colors, n_colors))
    for a, b in pairs:
        joint[a, b] += 1
    joint /= n

    p_x = joint.sum(axis=1)
    p_y = joint.sum(axis=0)

    mi = 0.0
    for i in range(n_colors):
        for j in range(n_colors):
            if joint[i, j] > 0:
                mi += joint[i, j] * np.log2(joint[i, j] / (p_x[i] * p_y[j]))

    if mi < 0.01:
        interp = f"MI ~ {mi:.4f} -- neighbors are nearly independent"
    elif mi < 0.1:
        interp = f"MI = {mi:.4f} -- weak dependence"
    else:
        interp = f"MI = {mi:.4f} -- strong dependence (structured pattern)"

    return {
        "mutual_information": mi,
        "interpretation": interp,
    }


# ── Summary ────────────────────────────────────────────────────────────


def summarize(results: dict) -> str:
    lines = ["=" * 60, "  RANDOMNESS EVALUATION SUMMARY", "=" * 60, ""]

    lines.append("[1] Color Distribution")
    lines.append(f"    Chi-square: p = {results['chi_square']['p_value']:.4f}")
    lines.append(f"    -> {results['chi_square']['interpretation']}")
    lines.append("")

    lines.append("[2] Shannon Entropy")
    lines.append(f"    {results['entropy']['interpretation']}")
    lines.append("")

    lines.append("[3] Spatial Autocorrelation (Moran's I)")
    lines.append(f"    I = {results['morans_i']['morans_i']:.4f}")
    lines.append(f"    -> {results['morans_i']['interpretation']}")
    lines.append("")

    lines.append("[4] 2D Runs Test (transitions)")
    lines.append(
        f"    Observed: {results['runs']['total_runs']}  Expected: {results['runs']['expected_total']:.1f}"
    )
    lines.append(f"    -> {results['runs']['interpretation']}")
    lines.append("")

    lines.append("[5] Mutual Information (right-neighbor)")
    lines.append(f"    MI = {results['mutual_info']['mutual_information']:.4f}")
    lines.append(f"    -> {results['mutual_info']['interpretation']}")
    lines.append("")

    # Overall verdict
    mi = results["mutual_info"]["mutual_information"]
    moran = abs(results["morans_i"]["morans_i"])
    run_ratio = results["runs"]["ratio"]

    random_votes = 0
    total_votes = 3
    if mi < 0.01:
        random_votes += 1
    if moran < 0.1:
        random_votes += 1
    if 0.9 <= run_ratio <= 1.1:
        random_votes += 1

    lines.append("-" * 60)
    if random_votes == total_votes:
        lines.append("  VERDICT: Pattern appears to be PURELY RANDOM (i.i.d.)")
    elif random_votes >= total_votes // 2:
        lines.append("  VERDICT: Pattern is MOSTLY RANDOM with weak spatial structure")
    else:
        lines.append(
            "  VERDICT: Pattern has SIGNIFICANT SPATIAL STRUCTURE (not random)"
        )
    lines.append("-" * 60)

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Evaluate randomness of tile matrix")
    parser.add_argument(
        "--matrix", default="output/matrix.txt", help="Path to tile matrix file"
    )
    args = parser.parse_args()

    print(f"Loading matrix from: {args.matrix}")
    matrix = load_matrix(args.matrix)
    print(f"Matrix shape: {matrix.shape[0]} x {matrix.shape[1]}")

    print("\nRunning randomness tests...\n")

    results = {
        "chi_square": chi_square_uniformity(matrix),
        "entropy": shannon_entropy(matrix),
        "morans_i": morans_i(matrix),
        "runs": runs_test_2d(matrix),
        "mutual_info": mutual_information_neighbor(matrix),
    }

    print(summarize(results))


if __name__ == "__main__":
    main()
